﻿public class Product
{
    public string ProductID { get; set; }
    public string Name { get; set; }
    public int OnHand { get; set; }
}